const modal = document.getElementById('passportModal');
const form = document.getElementById('passportForm');
const closeModal = document.getElementById('closeModal');
const addBtn = document.querySelector('.btn');

const passportCard = document.getElementById('passportCard');
const passportPhoto = document.getElementById('passportPhoto');
const passportName = document.getElementById('passportName');
const passportPesel = document.getElementById('passportPesel');

addBtn.addEventListener('click', () => {
  modal.style.display = 'flex';
});

closeModal.addEventListener('click', () => {
  modal.style.display = 'none';
});

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const name = document.getElementById('name').value;
  const surname = document.getElementById('surname').value;
  const pesel = document.getElementById('pesel').value;
  const photo = document.getElementById('photo').files[0];

  const reader = new FileReader();
  reader.onloadend = () => {
    const imgData = reader.result;
    const passportData = { name, surname, pesel, photo: imgData };
    localStorage.setItem('passportData', JSON.stringify(passportData));
    updatePassportCard(passportData);
    modal.style.display = 'none';
  };

  if (photo) {
    reader.readAsDataURL(photo);
  } else {
    const passportData = { name, surname, pesel };
    localStorage.setItem('passportData', JSON.stringify(passportData));
    updatePassportCard(passportData);
    modal.style.display = 'none';
  }
});

function updatePassportCard(data) {
  passportName.textContent = `${data.name} ${data.surname}`;
  passportPesel.textContent = `PESEL: ${data.pesel}`;
  if (data.photo) {
    passportPhoto.src = data.photo;
  }
}

window.addEventListener('load', () => {
  const saved = localStorage.getItem('passportData');
  if (saved) {
    updatePassportCard(JSON.parse(saved));
  }
});